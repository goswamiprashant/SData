from utils.helper import get_bbox_from_heatmap,predict_new
import torch
from torchvision import transforms
from matplotlib.patches import Rectangle
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
import base64
import io
import os,shutil
import cv2
import datetime
from test import testing
NEG_CLASS=1
class_names=["Good","Anomaly"]
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
heatmap_thres = 0.7

def base64_to_image(enc_str):
    """
    Decodes a base64 string to an image and returns it as a Numpy array.
    The image will be resized using OpenCV to a resolution of 224x224 pixels.
    """
    dec_str = base64.b64decode(enc_str)
    img = Image.open(io.BytesIO(dec_str))
    img_arr = np.asarray(img)
    return img_arr   
    
def predict_anomaly(inspection,path):
    # ct stores current time
    ct = datetime.datetime.now()
    ts = ct.timestamp()
    img_name = "output_"+str(ct)+".png"
    #data =request.get_json(force=True)
    #base64_encoded_str = data['photo']
    base64_encoded_str = testing(path)
    show_heatmap=True
    subset_name =inspection 
    model_path = f"weightsnew/{subset_name}_model.h5"
    model = torch.load(model_path, map_location=device)
    img = base64_to_image(base64_encoded_str)
    img = cv2.resize(img,dsize=(224,224))
    transform_to_PIL = transforms.ToPILImage()
    img = img.T
    inpf = torch.from_numpy(img)
    inpf = inpf.reshape((1,3,224,224))
    inpf = inpf.reshape((1,1,3,224,224))
    inpf= inpf/255
    img_name=predict_new(model, inpf, device, thres=heatmap_thres, n_samples=20,show_heatmap=False)
    return img_name
    '''
    for inputs in inpf:
	    inputs = inputs.to(device)
	    out = model(inputs)
	    probs, class_preds = torch.max(out[0], dim=-1)
	    feature_maps = out[1].to("cpu")
	    for img_i in range(inputs.size(0)):
		    img = transform_to_PIL(inputs[img_i])
		    class_pred = class_preds[img_i]
		    prob = probs[img_i]
		    heatmap = feature_maps[img_i][NEG_CLASS].detach().numpy()
		    plt.imshow(img)
		    #plt.savefig(img_name)
		    plt.axis("off")
		    #plt.show()
		    plt.title(
		        "Predicted: {}, Prob: {:.3f},".format(
		            class_names[class_pred], prob
		        )
		    )

		    if class_pred == NEG_CLASS:
		        x_0, y_0, x_1, y_1 = get_bbox_from_heatmap(heatmap, heatmap_thres)
		        rectangle = Rectangle(
		            (x_0, y_0),
		            x_1 - x_0,
		            y_1 - y_0,
		            edgecolor="red",
		            facecolor="none",
		            lw=3,
		        )
		        plt.gca().add_patch(rectangle)
		        #plt.savefig("output_new3.png")
		        if show_heatmap:
		            plt.imshow(heatmap, cmap="Reds", alpha=0.3)
		        plt.savefig("static/"+img_name)
		        plt.tight_layout()
		        #plt.show()
		        #plt.savefig("output.png") 
	    #plt.show()	        
	    plt.savefig("static/"+img_name)  '''  
