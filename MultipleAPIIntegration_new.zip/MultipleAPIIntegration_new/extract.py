import tarfile
def extract(filename,destination):
	file = tarfile.open(filename)
	file.extractall(destination)
	file.close() 

