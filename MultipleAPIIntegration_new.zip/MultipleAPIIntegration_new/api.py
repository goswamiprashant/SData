from flask import Flask, render_template, request,url_for
import sys
#from werkzeug import secure_filename
sys.path.append('/home/prashant/.local/lib/python3.8/site-packages')
from Inspect import training
import tarfile
from extract import extract
from VAI_API_new import base64_to_image,predict_anomaly
app = Flask(__name__)
app.config['UPLOAD_FOLDER']='static'

@app.route('/', methods = ['GET', 'POST'])
def home():
    return render_template('index.html')
@app.route('/upload', methods = ['GET', 'POST'])
def upload():
   return render_template('upload.html')
	
@app.route('/uploader_new', methods = ['GET', 'POST'])
def uploader_new():
   if request.method == 'POST':
      f = request.files['file']
      f.save(f.filename)
      extract(f.filename,'data')
      return render_template('upload.html',response_text='File uploaded successfully')
      #return 'file uploaded successfully'
      
@app.route('/admin_sec', methods = ['GET', 'POST'])
def admin_sec():
     return render_template('admin_sec.html')
     
@app.route('/train', methods = ['GET', 'POST'])
def train():
     return render_template('train.html') 
     
@app.route('/test', methods = ['GET', 'POST'])
def test():
     return render_template('test.html')     
     
@app.route('/Training', methods = ['GET', 'POST'])
def Training():
     inspection =request.form.get("inspection")
     output = training(inspection)
     return render_template('train.html',output_text='Training has been completed successfully.') 
     
@app.route('/Testing', methods = ['GET', 'POST']) 
def Testing():
     f = request.files['file']
     f.save(f.filename)
     inspection =request.form.get("inspection")
     output = predict_anomaly(inspection,f.filename)
     #output =f.filename
     return render_template('test.html',output_text=output)
		
if __name__ == '__main__':
   app.run(debug = True,port=1081)

