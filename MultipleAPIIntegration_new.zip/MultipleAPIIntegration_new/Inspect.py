import os
import numpy as np
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
import torch.optim as optim
import argparse
import warnings
warnings.filterwarnings("ignore")
from utils.dataloader import get_train_test_loaders, get_cv_train_test_loaders
from utils.model import CustomVGG
from utils.helper import train, evaluate, predict_localize
from utils.constants import NEG_CLASS 
from utils.constants import INPUT_IMG_SIZE as input_size

def training(inspection):
	training ="Yes"
	data_folder = "data/"
	subset_name =inspection
	data_folder = os.path.join(data_folder, subset_name)


	batch_size = 10
	target_train_accuracy = 0.98
	lr = 0.0001
	epochs = 1
	class_weight = [1, 3] if NEG_CLASS == 1 else [3, 1]
	device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

	heatmap_thres = 0.7
	n_cv_folds = 5
	train_loader, test_loader = get_train_test_loaders(
	    root=data_folder, batch_size=batch_size, test_size=0.2, random_state=42,
	)
	if training=="Yes":
	      model = CustomVGG()
	      class_weight = torch.tensor(class_weight).type(torch.FloatTensor).to(device)
	      criterion = nn.CrossEntropyLoss(weight=class_weight)
	      optimizer = optim.Adam(model.parameters(), lr=lr)
	      model = train(
	      train_loader, model, optimizer, criterion, epochs, device, target_train_accuracy) 
	      model_path = f"weightsnew/{subset_name}_model.h5"
	      torch.save(model, model_path)
	      output="Traning has been completed successfully"
	      return (output)

def testing():
		model_path = f"weightsnew/{subset_name}_model.h5"
		model = torch.load(model_path, map_location=device)
		predict_localize(
		    model, test_loader, device, thres=heatmap_thres, n_samples=15, show_heatmap=False
		)
