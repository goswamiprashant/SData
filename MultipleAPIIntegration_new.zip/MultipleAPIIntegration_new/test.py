import requests
from PIL import Image
import base64
import io
import argparse

# Initialize parser
#parser = argparse.ArgumentParser()

# Adding optional argument
#parser.add_argument("-I", "--Inspection", help = "Inspection name")
#parser.add_argument("-p", "--path", help = "test image path")

# Read arguments from command line
#args = parser.parse_args()
def testing(path):
	inspection = "toothbrush"
	path = path
	with open(path, "rb") as img_file:
	      b64_string = base64.b64encode(img_file.read())
	b64_string_fl = str(b64_string)[1:]
	return b64_string_fl

